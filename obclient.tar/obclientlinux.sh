mkdir /media/cool
mount 192.168.122.163:/mnt/cool /media/cool
