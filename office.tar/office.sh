ssh -X test@192.168.122.163 libreoffice4.3
